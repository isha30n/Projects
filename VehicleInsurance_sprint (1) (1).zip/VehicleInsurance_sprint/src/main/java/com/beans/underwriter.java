package com.beans;
import java.util.Arrays;
import java.util.List;


/* 
 *  the structure of the underWriter
 * 
 * 
 * */
public class underwriter
{
	private int UnderWriterId;
	private String Name;
	private String Dob;
	private String Joining_date;
	private String Password;
	private String[] Vehicles_registered = new String[0];
	public underwriter(int id,String name,String Dob,String jod)
	{
		this.UnderWriterId = id;
		this.Name = name;
		this.Dob=Dob;
		this.Joining_date=jod;
		this.Password="deafult_pwd@123";
	}
	
	public int getId()
	{
		//this returns the id of the underwriter
		return this.UnderWriterId;
	}
	public void setId(int id)
	{
		this.UnderWriterId=id;
	}
	public String getName()
	{
		return this.Name;
	}
	public String getDob()
	{
		return this.Dob;
	}
	public String getJod()
	{
		return this.Joining_date;
	}
	void setPwd(String pwd)
	{
		this.Password=pwd;
	}
	public String getPwd()
	{
		return this.Password;
	}
	public void setDoj(String doj) {
		this.Joining_date = doj;
	}

	public void add_vehicle_to_underwriter(String vno)
	{
		this.Vehicles_registered = Arrays.copyOf(this.Vehicles_registered,this.Vehicles_registered.length+1);
		this.Vehicles_registered[this.Vehicles_registered.length -1]=vno;
	}
	public void vehicles_registered_by_underwriter()
	{
		for(int i=0;i<this.Vehicles_registered.length -1;i++)
		{
			System.out.println(Vehicles_registered[i]);
		}
	}
	
}

