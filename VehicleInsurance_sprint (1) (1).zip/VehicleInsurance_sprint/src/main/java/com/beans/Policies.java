package com.beans;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;


public class Policies {
	private long policyNo;
	private String vehicleNo;
	private String vehicleType;
	private String customerName;
	private int engineNo;
	private int chasisNo;
	private long phoneNo;
	private String typeOfInsurance;
	private double premiumAmnt;
	private String fromDate;
	private String toDate;
	private int underWriterId;
	String getToDate(String s)
	{
		DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate date=LocalDate.parse(s,format);
		LocalDate ndate=date.plusDays(365);
		String newdate=ndate.format(format);
		return newdate;
	}
	public Policies(long policyNo,String vehicleNo,String vehicleType,
			String customerName,int engineNo,int chasisNo,long phoneNo,String typeOfInsurance,
			double premiumAmnt2, String fromDate,String toDate2, int underWriterId) {
		this.policyNo = policyNo;
		this.vehicleNo = vehicleNo;
		this.vehicleType=vehicleType;
		this.customerName=customerName;
		this.engineNo=engineNo;
		this.chasisNo=chasisNo;
		this.phoneNo=phoneNo;
		this.typeOfInsurance=typeOfInsurance;
		this.premiumAmnt= premiumAmnt2;
		
		this.fromDate=fromDate;
		this.toDate=getToDate(this.fromDate);
		this.underWriterId=underWriterId;
		
	}

	public long getPolicyNo()
	{
		return this.policyNo;
	}
	public String getVehicleNo() {
		return this.vehicleNo;
	}
	public String getVehicleType() {
		return this.vehicleType;
	}
	public String getCustomerName() {
		return this.customerName;
	}
	public int getEngineNo() {
		return this.engineNo;
	}
	public int getChasisNo() {
		return this.chasisNo;
	}
	public long getPnhNo()
	{
		return this.phoneNo;
	}
	public String getTypeOfInsurance() {
		return this.typeOfInsurance;
	}
	public double getPremiumAmnt()
	{
		return this.premiumAmnt;
	}
	public String getFromDate() {
		return this.fromDate;
	}
	public String getToDate() {
		return this.toDate;
	}
	public int getUnderWriterId() {
		return this.underWriterId;
	}
	public void setTypeOfInsurance(String newInsurance) {
		this.typeOfInsurance=newInsurance;
	}
	public void setPremiumAmnt(double amnt)
	{
		this.premiumAmnt=amnt;
	}
	public void setToDate(String todate)
	{
		this.toDate=todate;
	}
	public String getInsuranceType() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
