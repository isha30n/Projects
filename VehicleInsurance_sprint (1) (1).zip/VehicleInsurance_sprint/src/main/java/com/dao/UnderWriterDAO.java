package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.beans.underwriter;

public class UnderWriterDAO {
	
    private static final String URL = DbConstants.DBURL;


    public static int generateId()
    {
    	 String sql = "select count(*) as cnt from UnderWriter_Details";

         try  {
         	Class.forName("org.sqlite.JDBC");
     		Connection conn = DriverManager.getConnection(URL);
     		Statement stmt = conn.createStatement();
             ResultSet rs=stmt.executeQuery(sql);
             int ans=1000;
             if(rs!=null)
             {
            	ans=rs.getInt("cnt")+ans;
             	stmt.close();
             	conn.close();
             	return ans;
             }
             stmt.close();
           	conn.close();
             	
         } 
         catch (SQLException | ClassNotFoundException e) {
             e.printStackTrace();
         }
  
     	return 1000;
    }
    
    public static boolean insert(underwriter underwriter) throws ClassNotFoundException {
    	
        String sql = "INSERT INTO UnderWriter_Details (underWriterId, name, dob, joiningDate) VALUES (?, ?, ?, ?)";

        try  {
        	Class.forName("org.sqlite.JDBC");
    		Connection conn = DriverManager.getConnection(URL);
    		PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, underwriter.getId());
            stmt.setString(2, underwriter.getName());
            stmt.setString(3, underwriter.getDob());
            stmt.setString(4, underwriter.getJod());
 

            int rs=stmt.executeUpdate();
            if(rs>0)
            {
            	stmt.close();
            	conn.close();
            	return true;
            }
            
            stmt.close();
        	conn.close();
        } 
        catch (SQLException e) {
            e.printStackTrace();
        }
    	return false;
    }
    
    public static void main(String arg[])
    {
    	System.out.println(generateId());
    }
}
