package com.dao;
import java.sql.*;
import java.util.*;

import com.beans.underwriter;
public class ViewAllUnderWriterDAO {
public static Connection getConnection() {
	Connection con=null;
	try {
		Class.forName("org.sqlite.JDBC");
		con = DriverManager.getConnection(DbConstants.DBURL);
	}
	catch (Exception e) {
		// TODO: handle exception
		System.out.println(e);
	}
	return con;
}
public static List<underwriter>Students() {
	List<underwriter> list = new ArrayList<underwriter>();
	try {
		Connection con = ViewAllUnderWriterDAO.getConnection();
		PreparedStatement ps = con.prepareStatement("select * from UnderWriter_Details;");
		ResultSet rs = ps.executeQuery();
		underwriter s = null;
		while (rs.next()) {
			 s = new underwriter(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4));
			 list.add(s);
		}
		con.close();
		
	} catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	}
	
	return list;
	
}
public static void main(String a[]) {
	List<underwriter> list =Students();
	System.out.println(list.get(0).getId());
}
}

