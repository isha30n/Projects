package com.dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class DeleteUnderWriterDAO {
	public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("org.sqlite.JDBC");
			con = DriverManager.getConnection(DbConstants.DBURL);
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		return con;
	}	
public static int delete(int id) {
int status = 0;
	try {
		Connection con = getConnection();
		PreparedStatement ps = con.prepareStatement("delete from UnderWriter_Details where underWriterId=?");
		ps.setInt(1, id);
		status = ps.executeUpdate();
		con.close();	
	} catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	}
	return status;	
}
public static void main(String a[])
{
	
}
}