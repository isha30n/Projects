package com.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.beans.Policies;

public class policyRegisterDao {
	
    private static final String URL = DbConstants.DBURL;


    public static int generateId()
    {
    	 String sql = "select count(*) as cnt from Policies";

         try  {
         	Class.forName("org.sqlite.JDBC");
     		Connection conn = DriverManager.getConnection(URL);
     		Statement stmt = conn.createStatement();
             ResultSet rs=stmt.executeQuery(sql);
             int ans=100;
             if(rs!=null)
             {
            	ans=rs.getInt("cnt")+ans;
             	stmt.close();
             	conn.close();
             	return ans;
             }
             stmt.close();
           	conn.close();
             	
         } 
         catch (SQLException | ClassNotFoundException e) {
             e.printStackTrace();
         }
  
     	return 100;
    }
    
    public static boolean insert(Policies user) throws ClassNotFoundException {
//    	CREATE TABLE Policies(
//    			policyId INTEGER NOT NULL,
//    			VehicleNo VARCHAR(15) NOT NULL,
//    			VehicleType VARCHAR(15) NOT NULL,
//    			CustomerName VARCHAR(15) NOT NULL,
//    			EngineNo INTEGER NOT NULL,
//    			ChasisNo INTEGER NOT NULL,
//    			PhoneNo  NUMBER(10,1) NOT NULL,
//    			TypeOfInsurance varchar(15) NOT NULL,
//    			PremiumAmnt INTEGER NOT NULL,
//    			FromDate varchar(10) NOT NULL,
//    			ToDate varchar(10) NOT NULL,
//    			underWriterId NOT NULL,
//    			PRIMARY KEY(policyId)
//    			);
        String sql = "INSERT INTO Policies (policyId, VehicleNo, VehicleType, CustomerName, EngineNo, ChasisNo, PhoneNo, TypeOfInsurance, PremiumAmnt, FromDate, ToDate, underWriterId) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try  {
        	Class.forName("org.sqlite.JDBC");
    		Connection conn = DriverManager.getConnection(URL);
    		PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setLong(1, user.getPolicyNo());
            stmt.setString(2, user.getVehicleNo());
            stmt.setString(3, user.getVehicleType());
            stmt.setString(4, user.getCustomerName());
            stmt.setInt(5, user.getEngineNo());
            stmt.setInt(6, user.getChasisNo());
            stmt.setLong(7, user.getPnhNo());
            stmt.setString(8, user.getTypeOfInsurance());
            stmt.setDouble(9, user.getPremiumAmnt());
            stmt.setString(10, user.getFromDate());
            stmt.setString(11, user.getToDate());
            stmt.setInt(12, user.getUnderWriterId());


            int rs=stmt.executeUpdate();
            if(rs>0)
            {
            	stmt.close();
            	conn.close();
            	return true;
            }
            
            stmt.close();
        	conn.close();
        } 
        catch (SQLException e) {
            e.printStackTrace();
        }
    	return false;
    }
    
//    public static void main(String arg[])
//    {
//    	System.out.println(generateId());
//    }
}
