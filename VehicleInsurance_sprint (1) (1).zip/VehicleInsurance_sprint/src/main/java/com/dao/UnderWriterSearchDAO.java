package com.dao;
import java.sql.Connection;

import java.sql.DriverManager;

import java.sql.PreparedStatement;

import java.sql.ResultSet;

import java.util.ArrayList;

import java.util.List;

import com.beans.*;

public class UnderWriterSearchDAO {

	    public static Connection getConnection() {
	        Connection con = null;
	        try {
	            Class.forName("org.sqlite.JDBC");
	            con = DriverManager.getConnection(DbConstants.DBURL);
	        }
	        catch (Exception e) {

	            // TODO: handle exception

	            System.out.println(e);

	        }

	        return con;

	        

	    }
	    public static String[] getUnderWriterById(int id) {

		    underwriter s = null;
		    
	        try {

	            Connection con = UnderWriterSearchDAO.getConnection();

	            PreparedStatement ps = con.prepareStatement("select * from UnderWriter_Details where underWriterId=?");
	            ps.setInt(1, id);
	            String[] arr=new String[4];
	            ResultSet rs = ps.executeQuery();
	            if (rs!=null) {
	                 arr[0]=String.valueOf(rs.getInt("underWriterId"));
	                 arr[1]=rs.getString("name");
	                 arr[2]=rs.getString("dob");
	                 arr[3]=rs.getString("joiningDate");
	                 rs.close();
	                 con.close();
	                 return arr;
	            }
	            con.close();
	        } catch (Exception e) {

	            e.printStackTrace();
	        }	   
	        return null;

	    }
}