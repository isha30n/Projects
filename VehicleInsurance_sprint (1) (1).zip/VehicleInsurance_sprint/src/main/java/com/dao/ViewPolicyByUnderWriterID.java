package com.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.beans.*;

public class ViewPolicyByUnderWriterID {

    public static underwriter getUnderwriter(Connection connection, String underwriterId) throws SQLException {
        String sql = "SELECT * FROM UnderWriter_Details WHERE underWriterId = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, underwriterId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new underwriter(rs.getInt("underWriterId"), rs.getString("name"), rs.getString("dob"), rs.getString("joiningDate"));
            }
            return null;
        }
    }

    public static List<Policies> getPolicies(Connection connection, String underwriterId) throws SQLException {
        String sql = "SELECT * FROM Policies WHERE underWriterId = ?";
        int n=Integer.parseInt(underwriterId);
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, n);
            ResultSet rs = null;
            		rs=pstmt.executeQuery();
            List<Policies> policies = new ArrayList<>();
            	
            while (rs.next()) { 
            	
            	Policies policy = new Policies(
                    rs.getLong("policyId"), 
                    rs.getString("vehicleNo"), 
                    rs.getString("vehicleType"), 
                    rs.getString("customerName"), 
                    rs.getInt("engineNo"), 
                    rs.getInt("chasisNo"), 
                    rs.getLong("phoneNo"), 
                    rs.getString("typeOfInsurance"), 
                    rs.getDouble("premiumAmnt"),
                    rs.getString("fromDate"), 
                    sql, rs.getInt("underWriterId")
                );
                policies.add(policy);
            }
            return policies;
        }
    }

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("org.sqlite.JDBC");
            String jdbcURL = DbConstants.DBURL;
            return DriverManager.getConnection(jdbcURL);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            throw new SQLException("SQLite JDBC Driver not found.");
        }
    }
}
