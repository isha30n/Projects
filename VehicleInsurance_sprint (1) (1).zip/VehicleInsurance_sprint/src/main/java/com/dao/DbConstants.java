package com.dao;

public class DbConstants {
	public static final String DRIVER = "org.sqlite.JDBC";
	public static final String DBURL = "jdbc:sqlite:C:\\Users\\2729029\\MySQLiteDB";
	public static final String DBUSER = "";
	public static final String DBPASSWORD = "";

}
