package com.dao;

import com.beans.Policies;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Date;
import java.sql.DriverManager;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;


public class RenewPolicyDAO {
	public static Connection getConnection() {
		Connection con=null;
		try {
			Class.forName("org.sqlite.JDBC");
			con = DriverManager.getConnection(DbConstants.DBURL);
		}
		catch (Exception e) {
			// TODO: handle exception
			System.out.println(e);
		}
		return con;
	}
    // Method to check if a policy ID exists and if it's expired
    public static boolean isPolicyExpired( Long policyId) throws SQLException {
    	Connection connection=getConnection();
        String sql = "SELECT ToDate FROM Policies WHERE VehicleNo = ? order by policyId DESC LIMIT 1;";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, getVehicleNo(policyId));
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
            	
            	String fdate= rs.getString("ToDate");
            	DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        		LocalDate ndate=LocalDate.parse(fdate,format);
        		LocalDate currentDate = LocalDate.now();
        		return ndate.isBefore(currentDate);
            }
        }
        return false;
    }
    
    public static String getVehicleNo( Long policyId) throws SQLException {
    	Connection connection=getConnection();
        String sql = "SELECT VehicleNo FROM Policies WHERE policyId = ?  ;";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setLong(1, policyId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
        		return rs.getString("VehicleNo");
            }
        }
        return null;
    }
    // Method to get the "toDate" of a policy
    public static LocalDate getPolicyToDate( Long policyId) throws SQLException {
    	Connection connection=getConnection();
        String sql = "SELECT ToDate FROM Policies WHERE VehicleNo = ?  order by policyId DESC LIMIT 1;";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, getVehicleNo(policyId));
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                String fdate= rs.getString("ToDate");
                DateTimeFormatter format = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        		LocalDate date=LocalDate.parse(fdate,format);
        		return date;
            }
        }
        return null;
    }

    // Method to create a new policy record
    public static boolean insert(Policies user) throws ClassNotFoundException {
//    	CREATE TABLE Policies(
//    			policyId INTEGER NOT NULL,
//    			VehicleNo VARCHAR(15) NOT NULL,
//    			VehicleType VARCHAR(15) NOT NULL,
//    			CustomerName VARCHAR(15) NOT NULL,
//    			EngineNo INTEGER NOT NULL,
//    			ChasisNo INTEGER NOT NULL,
//    			PhoneNo  NUMBER(10,1) NOT NULL,
//    			TypeOfInsurance varchar(15) NOT NULL,
//    			PremiumAmnt INTEGER NOT NULL,
//    			FromDate varchar(10) NOT NULL,
//    			ToDate varchar(10) NOT NULL,
//    			underWriterId NOT NULL,
//    			PRIMARY KEY(policyId)
//    			);
        String sql = "INSERT INTO Policies (policyId, VehicleNo, VehicleType, CustomerName, EngineNo, ChasisNo, PhoneNo, TypeOfInsurance, PremiumAmnt, FromDate, ToDate, underWriterId) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try  {
        	
    		Connection conn = getConnection();
    		PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setLong(1, user.getPolicyNo());
            stmt.setString(2, user.getVehicleNo());
            stmt.setString(3, user.getVehicleType());
            stmt.setString(4, user.getCustomerName());
            stmt.setInt(5, user.getEngineNo());
            stmt.setInt(6, user.getChasisNo());
            stmt.setLong(7, user.getPnhNo());
            stmt.setString(8, user.getTypeOfInsurance());
            stmt.setDouble(9, user.getPremiumAmnt());
            stmt.setString(10, user.getFromDate());
            stmt.setString(11, user.getToDate());
            stmt.setInt(12, user.getUnderWriterId());


            int rs=stmt.executeUpdate();
            if(rs>0)
            {
            	stmt.close();
            	conn.close();
            	return true;
            }
            
            stmt.close();
        	conn.close();
        } 
        catch (SQLException e) {
            e.printStackTrace();
        }
    	return false;
    }
    public static int generateId()
    {
    	 String sql = "select count(*) as cnt from Policies";

         try  {
         	
     		Connection conn = getConnection();
     		Statement stmt = conn.createStatement();
             ResultSet rs=stmt.executeQuery(sql);
             int ans=101;
             if(rs!=null)
             {
            	ans=rs.getInt("cnt")+ans;
             	stmt.close();
             	conn.close();
             	return ans;
             }
             stmt.close();
           	conn.close();
             	
         } 
         catch (SQLException e) {
             e.printStackTrace();
         }
  
     	return 100;
    }
	public static boolean createNewPolicy(long policyId, double premiumAmount) throws SQLException {
		Policies policy = null;
        try {
        	Connection con = getConnection();
        	PreparedStatement pstmt = con.prepareStatement("SELECT * FROM Policies WHERE policyId = ?");
        		pstmt.setLong(1, policyId);
        		ResultSet rs = pstmt.executeQuery();
        		if (rs!=null) {
        			long policyNo = generateId();
        			String vehicleNo = rs.getString("VehicleNo");
        			String vehicleType = rs.getString("VehicleType");
        			String customerName = rs.getString("CustomerName");
        			int engineNo = rs.getInt("EngineNo");
        			int chasisNo = rs.getInt("ChasisNo");
        			long phoneNo = rs.getLong("PhoneNo");
        			String typeOfInsurance = rs.getString("TypeOfInsurance");
        			double premiumAmnt =premiumAmount;
        			String fromDate = getPolicyToDate(policyId).toString();
        			String toDate =getPolicyToDate(policyId).plusDays(365).toString();
        			int underWriterId = rs.getInt("underWriterId");
        			
        			
        			policy = new Policies(policyNo, vehicleNo, vehicleType, customerName, engineNo, chasisNo, phoneNo, 
        					typeOfInsurance, premiumAmnt, fromDate, toDate, underWriterId);
        			rs.close();
        			con.close();
        			return insert(policy);
        			
        		}
        
            }
  
         catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        
        return false;
	}
    public static void main(String a[]) throws SQLException
    {
    	System.out.print(isPolicyExpired((long) 104));
    }
}