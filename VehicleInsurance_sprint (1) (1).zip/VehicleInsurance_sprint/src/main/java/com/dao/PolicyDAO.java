package com.dao;
import com.beans.Policies;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class PolicyDAO {
    private static String jdbcURL = DbConstants.DBURL;

    private static final String SELECT_POLICY_BY_ID = "SELECT * FROM Policies WHERE policyId = ?";
    private static final String UPDATE_POLICY_TYPE = "UPDATE Policies SET TypeOfInsurance = ? WHERE policyId = ?";
    
    public static Policies getPolicyById(int id, int uid) throws ClassNotFoundException {
        Policies policy = null;
        try {
        	Class.forName("org.sqlite.JDBC");
        	
        	Connection con = DriverManager.getConnection(jdbcURL);
        	PreparedStatement pstmt = con.prepareStatement("SELECT * FROM Policies WHERE policyId = ? and underWriterId = ?");
        		pstmt.setInt(1, id);
        		pstmt.setInt(2, uid);
        		ResultSet rs = pstmt.executeQuery();
        		if (rs!=null) {
        			long policyNo = rs.getLong("policyId");
        			String vehicleNo = rs.getString("VehicleNo");
        			String vehicleType = rs.getString("VehicleType");
        			String customerName = rs.getString("CustomerName");
        			int engineNo = rs.getInt("EngineNo");
        			int chasisNo = rs.getInt("ChasisNo");
        			long phoneNo = rs.getLong("PhoneNo");
        			String typeOfInsurance = rs.getString("TypeOfInsurance");
        			double premiumAmnt = rs.getDouble("PremiumAmnt");
        			String fromDate = rs.getString("FromDate");
        			String toDate = rs.getString("ToDate");
        			int underWriterId = rs.getInt("underWriterId");
        			
        			policy = new Policies(policyNo, vehicleNo, vehicleType, customerName, engineNo, chasisNo, phoneNo, 
        					typeOfInsurance, premiumAmnt, fromDate, toDate, underWriterId);
        			
        			rs.close();
        			con.close();
        		}
        
            }
  
         catch (SQLException e) {
            e.printStackTrace();
        }
        return policy;
    }

    public static void updatePolicyType(int policyId, String newType) {
        try {
        	Connection connection = DriverManager.getConnection(jdbcURL);
        	Class.forName("org.sqlite.JDBC");
             PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_POLICY_TYPE);
            preparedStatement.setString(1, newType);
            preparedStatement.setInt(2, policyId);
            preparedStatement.executeUpdate();
        } 
        catch (Exception e) {
            e.printStackTrace();
        }
    }
//    public static void main(String[] args) throws ClassNotFoundException {
//        PolicyDAO policyDAO = new PolicyDAO();
//        
//        // Update the policy type
//        int policyId = 102; // Example policy ID
//        String newType = "Third Party Insured";
//        policyDAO.updatePolicyType(policyId, newType);
//
//        Policy updatedPolicy = policyDAO.getPolicyById(policyId);
//        if (updatedPolicy != null) {
//            System.out.println("Updated Policy Type: " + updatedPolicy.getTypeOfInsurance());
//        } else {
//            System.out.println("Policy not found.");
//        }
}

