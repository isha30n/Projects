package com.dao;
import java.sql.*;
import java.util.*;

import com.beans.Policies;

public class sqlite {
		public static boolean underwriter_login(int id,String pwd)
		{
			Connection connection=null;
			try {
				connection = db_connection();
				String sql = "select password from UnderWriter_Details where underWriterId="+id+";" ;
				Statement stmpt;
				stmpt = connection.createStatement();
				stmpt = connection.createStatement();
				ResultSet resultObj;
				resultObj = stmpt.executeQuery(sql);
				String pw=resultObj.getString("password");
				if(pw.equals(pwd)) 
				{
					stmpt.close();connection.close();
					return true;
				}
				stmpt.close();connection.close();
				return false;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return false;
		}
			
		
			
		public static boolean add_underwriter(Connection connection,int Id, String name, String dob, String job) throws SQLException
		{
			String sql = "insert into UnderWriter_Details (underWriterId,name, dob, job) values (?,?,?,?)";
			PreparedStatement pstmt = connection.prepareStatement(sql);
			pstmt.setInt(1, Id);
			pstmt.setString(2, name);
			pstmt.setString(3, dob);
			pstmt.setString(4, job);
			int rows=pstmt.executeUpdate();
			pstmt.close();
			connection.close();
			if(rows>0) return true;
			return false;
		}
		public static boolean add_policy(Connection connection,long pId, String vno, String vtype, String name,int eno,int cno,long pno,String itype,long pamnt,String fdate,String todate,int uid) throws SQLException
		{
			String sql = "insert into Policies (policyId,VehicleNo,VehicleType, CustomerName,EngineNo,ChasisNo,PhoneNo,TypeOfInsurance,PremiumAmnt,FromDate,ToDate,underWriterId) values (?,?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement pstmt = connection.prepareStatement(sql);
			pstmt.setLong(1, pId);
			pstmt.setString(2, vno);
			pstmt.setString(3, vtype);
			pstmt.setString(4, name);
			pstmt.setInt(5, eno);
			pstmt.setInt(6, cno);
			pstmt.setLong(7, pno);
			pstmt.setString(8, itype);
			pstmt.setLong(9, pamnt);
			pstmt.setString(10, fdate);
			pstmt.setString(11, todate);
			pstmt.setInt(12, uid);
			int rows=pstmt.executeUpdate();
			pstmt.close();
			connection.close();
			if(rows>0) return true;
			return false;
		}
		public static String[] viewPolicy(int pid, int uid)
		{
			Connection connection=null;
			ResultSet resultObj=null;
			Statement stmpt =null;
			String[] arr=new String[12];
			try {
			connection = db_connection();
			String sql = "select * from policies where policyId="+pid +" and underWriterId="+uid;
			stmpt = connection.createStatement();
			
			resultObj = stmpt.executeQuery(sql);
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
			
			try {
			if(resultObj!=null) {
				
				arr[0]=String.valueOf(resultObj.getInt("policyId"));
				
				arr[1]=resultObj.getString("VehicleNo");
				arr[2]=resultObj.getString("VehicleType");
				arr[3]=resultObj.getString("CustomerName");
				arr[4]=String.valueOf(resultObj.getInt("EngineNo"));
				arr[5]=String.valueOf(resultObj.getInt("ChasisNo"));
				arr[6]=resultObj.getString("PhoneNo");
				arr[7]=resultObj.getString("TypeOfInsurance");
				arr[8]=String.valueOf(resultObj.getInt("PremiumAmnt"));
				arr[9]=resultObj.getString("FromDate");
				arr[10]=resultObj.getString("ToDate");
				arr[11]=String.valueOf(resultObj.getInt("underWriterId"));
				resultObj.close();
				stmpt.close();
				connection.close();
				return arr;
			}
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
			return null;
			
		}
		public static Connection db_connection() throws SQLException
		{
			try {
				Class.forName("org.sqlite.JDBC");
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			String jdbcURL =  DbConstants.DBURL;
			Connection connection = null;
			
			connection = DriverManager.getConnection(jdbcURL);
			if(connection!=null) {
			System.out.println("The connection is established");
			}
			else {
				System.out.println("Error in establishing connection ");
			}
			return connection;
		}
		public static boolean policy_renewal(Connection connection,long pId,long pamnt,String fdate,String todate,int uid) throws SQLException
		{
			String sql = "insert into Policy_Renewal values (?,?,?,?,?)";
			PreparedStatement pstmt = connection.prepareStatement(sql);
			pstmt.setLong(1, pId);
			pstmt.setLong(2, pamnt);
			pstmt.setString(3, fdate);
			pstmt.setString(4, todate);
			pstmt.setInt(5, uid);
			int rows=pstmt.executeUpdate();
			pstmt.close();
			connection.close();
			if(rows>0) return true;
			return false;
		}
		public static boolean search(long id)  {
	        
			Connection connection=null;
			ResultSet resultObj=null;
			Statement stmpt =null;
			
			try {
			connection = db_connection();
			String sql = "select * from Policies where policyId="+id;
			stmpt = connection.createStatement();
			
			resultObj = stmpt.executeQuery(sql);
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
			
			
			try {
				if(resultObj.next()) {
					System.out.println("hi");
					resultObj.close();
					stmpt.close();
					connection.close();
					return true;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return false;
	    }

	    public static Policies displayPolicies(int id) {
	        Policies policy = null;
	        try {
	        	
	        	Connection con = db_connection();
	        	PreparedStatement pstmt = con.prepareStatement("SELECT * FROM Policies WHERE policyId = ?");
	        		pstmt.setInt(1, id);
	        		ResultSet rs = pstmt.executeQuery();
	        		if (rs!=null) {
	        			long policyNo = rs.getLong("policyId");
	        			String vehicleNo = rs.getString("VehicleNo");
	        			String vehicleType = rs.getString("VehicleType");
	        			String customerName = rs.getString("CustomerName");
	        			int engineNo = rs.getInt("EngineNo");
	        			int chasisNo = rs.getInt("ChasisNo");
	        			long phoneNo = rs.getLong("PhoneNo");
	        			String typeOfInsurance = rs.getString("TypeOfInsurance");
	        			double premiumAmnt = rs.getDouble("PremiumAmnt");
	        			String fromDate = rs.getString("FromDate");
	        			String toDate = rs.getString("ToDate");
	        			int underWriterId = rs.getInt("underWriterId");
	        			
	        			policy = new Policies(policyNo, vehicleNo, vehicleType, customerName, engineNo, chasisNo, phoneNo, 
	        					typeOfInsurance, premiumAmnt, fromDate, toDate, underWriterId);
	        			
	        			rs.close();
	        		}
	        
	            }
	  
	         catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return policy;
	    }
		public static void main(String[] args) throws SQLException {
			String[] arr=viewPolicy(102,1001);
			System.out.println(arr[0]);
			
			
		}
	}
