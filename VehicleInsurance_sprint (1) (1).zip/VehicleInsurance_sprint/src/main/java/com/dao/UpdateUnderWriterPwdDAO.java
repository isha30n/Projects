package com.dao;
import java.sql.*;

public class UpdateUnderWriterPwdDAO {

    public static boolean underwriterExists(Connection connection, String underwriterId) throws SQLException {
        String sql = "SELECT * FROM UnderWriter_Details WHERE underWriterId = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, underwriterId);
            ResultSet rs = pstmt.executeQuery();
            return rs.next();
        }
    }

    public static void updatePassword(Connection connection, String underwriterId, String newPassword) throws SQLException {
        String sql = "UPDATE UnderWriter_Details SET password = ? WHERE underWriterId = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, newPassword);
            ps.setString(2, underwriterId);
            ps.executeUpdate();
        }
    }

    public static Connection getConnection() throws SQLException {
    	try {
    		Class.forName("org.sqlite.JDBC");
    		String jdbcURL = DbConstants.DBURL;
            return DriverManager.getConnection(jdbcURL);		
    	}
    	catch (ClassNotFoundException e) {
            e.printStackTrace();
            throw new SQLException("SQLite JDBC Driver not found.");
        }
        
    }
}
